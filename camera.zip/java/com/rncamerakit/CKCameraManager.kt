package com.rncamerakit

import android.util.Log
import com.facebook.react.bridge.ReadableArray
import com.facebook.react.bridge.ReadableType
import com.facebook.react.common.MapBuilder
import com.facebook.react.uimanager.SimpleViewManager
import com.facebook.react.uimanager.ThemedReactContext
import com.facebook.react.uimanager.annotations.ReactProp
import android.widget.FrameLayout

class CKCameraManager : SimpleViewManager<FrameLayout>() {

    private val TAG = "CKCameraManager"

    override fun getName(): String {
        return "CKCameraManager"
    }

    override fun createViewInstance(context: ThemedReactContext): FrameLayout {
        return try {
            val ckCamera = CKCamera(context)

            // Check if the camera is bound and functional
            if (ckCamera.isCameraBound) {
                Log.d(TAG, "CKCamera is successfully bound.")
                CameraFallback(context)

            } else {
                Log.w(TAG, "CKCamera is not bound. Switching to fallback.")
                ckCamera // Fallback to another camera implementation
            }
        } catch (e: Exception) {
            Log.e(TAG, "CKCamera failed to initialize. Switching to fallback.", e)
            CameraFallback(context) // Fallback to another camera implementation
        }
    }

    override fun receiveCommand(view: FrameLayout, commandId: String?, args: ReadableArray?) {
        if (args == null) {
            Log.d(TAG, "CameraManager received command $commandId with no arguments")
            return
        }

        var logCommand = "CameraManager received command $commandId("
        for (i in 0 until args.size()) {
            if (i > 0) {
                logCommand += ", "
            }
            logCommand += when (args.getType(i)) {
                ReadableType.Null -> "Null"
                ReadableType.Array -> "Array"
                ReadableType.Boolean -> "Boolean"
                ReadableType.Map -> "Map"
                ReadableType.Number -> "Number"
                ReadableType.String -> "String"
                else -> ""
            }
        }
        logCommand += ")"
        Log.d(TAG, logCommand)
    }


    @ReactProp(name = "scanBarcode")
    fun setScanBarcode(view: FrameLayout, enabled: Boolean) {
        when (view) {
            is CKCamera -> {
                view.setScanBarcode(enabled)
            }
            is CameraFallback -> {
                // Ensure CameraFallback has a similar method or implement its barcode scanning logic
                view.setScanBarcode(enabled)
            }
            else -> {
                Log.w(TAG, "scanBarcode: Unsupported view type")
            }
        }
    }





    override fun getExportedCustomDirectEventTypeConstants(): Map<String, Any> {
        return MapBuilder.of(
            "onReadCode", MapBuilder.of("registrationName", "onReadCode"),
            "onError", MapBuilder.of("registrationName", "onError"),
            "onCameraInitialized", MapBuilder.of("registrationName", "onCameraInitialized")
        )
    }





}

