package com.rncamerakit

import com.facebook.react.bridge.*
import com.facebook.react.uimanager.UIManagerModule

/**
 * Native module for interacting with the camera in React Native applications.
 *
 * This module provides methods to capture photos using the camera and constants
 * related to camera orientation.
 *
 * @param reactContext The application's ReactApplicationContext.
 */
class RNCameraKitModule(private val reactContext: ReactApplicationContext) : ReactContextBaseJavaModule(reactContext) {



    override fun getName(): String {
        return "RNCameraKitModule"
    }

}
