package com.rncamerakit

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.hardware.camera2.*
import android.media.ImageReader
import android.util.Log
import android.util.Size
import android.view.Surface
import android.view.TextureView
import android.widget.FrameLayout
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.facebook.react.uimanager.ThemedReactContext
import com.google.zxing.*
import com.google.zxing.common.HybridBinarizer
import java.nio.ByteBuffer
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit
import com.facebook.react.bridge.ReactContext
import com.facebook.react.bridge.Arguments
import com.facebook.react.uimanager.events.RCTEventEmitter


class CameraFallback(context: ThemedReactContext) : FrameLayout(context) {

    private lateinit var cameraManager: CameraManager
    private var cameraDevice: CameraDevice? = null
    private var cameraCaptureSession: CameraCaptureSession? = null
    private lateinit var captureRequestBuilder: CaptureRequest.Builder
    private lateinit var textureView: TextureView
    private lateinit var imageReader: ImageReader
    private val cameraId = "0" // Rear camera
    private val cameraOpenCloseLock = Semaphore(1) // Lock to prevent multiple open/close calls
    private var scanBarcodeEnabled: Boolean = false

    init {
        textureView = TextureView(context)
        addView(textureView)

        cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(context.currentActivity!!, arrayOf(Manifest.permission.CAMERA), 100)
        } else {
            setupTextureView()
        }
    }

    private fun setupTextureView() {
        textureView.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(surfaceTexture: android.graphics.SurfaceTexture, width: Int, height: Int) {
                openCamera()
            }

            override fun onSurfaceTextureSizeChanged(surfaceTexture: android.graphics.SurfaceTexture, width: Int, height: Int) {}

            override fun onSurfaceTextureDestroyed(surfaceTexture: android.graphics.SurfaceTexture): Boolean {
                closeCamera() // Close camera when surface is destroyed
                return true
            }

            override fun onSurfaceTextureUpdated(surfaceTexture: android.graphics.SurfaceTexture) {}
        }
    }

    private fun openCamera() {
        try {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                // Try acquiring the lock, return if not successful to avoid conflicts
                if (!cameraOpenCloseLock.tryAcquire(2500, TimeUnit.MILLISECONDS)) {
                    throw RuntimeException("Time out waiting to lock camera opening.")
                }
                cameraManager.openCamera(cameraId, cameraStateCallback, null)
            }
        } catch (e: CameraAccessException) {
            Log.e("CameraFallback", "Failed to access camera: ${e.message}")
        } catch (e: InterruptedException) {
            throw RuntimeException("Interrupted while trying to lock camera opening.", e)
        }
    }

    private val cameraStateCallback = object : CameraDevice.StateCallback() {
        override fun onOpened(camera: CameraDevice) {
            cameraDevice = camera
            cameraOpenCloseLock.release() // Release the lock
            createCameraPreviewSession()
        }

        override fun onDisconnected(camera: CameraDevice) {
            camera.close()
            cameraDevice = null
            cameraOpenCloseLock.release() // Release the lock
        }

        override fun onError(camera: CameraDevice, error: Int) {
            camera.close()
            cameraDevice = null
            cameraOpenCloseLock.release() // Release the lock
            Toast.makeText(context, "Failed to open camera", Toast.LENGTH_SHORT).show()
        }
    }



    fun setScanBarcode(enabled: Boolean) {
        this.scanBarcodeEnabled = enabled
    }


    private fun createCameraPreviewSession() {
        try {
            val surfaceTexture = textureView.surfaceTexture
            if (surfaceTexture == null) {
                Log.e("CameraFallback", "SurfaceTexture is null, cannot create preview session")
                return
            }

            surfaceTexture.setDefaultBufferSize(640, 480)
            val surface = Surface(surfaceTexture)

            imageReader = ImageReader.newInstance(640, 480, ImageFormat.YUV_420_888, 2)

            imageReader.setOnImageAvailableListener({ reader ->
                if (!scanBarcodeEnabled) return@setOnImageAvailableListener

                val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                val buffer: ByteBuffer = image.planes[0].buffer
                val bytes = ByteArray(buffer.remaining())
                buffer.get(bytes)
                image.close()

                val source = PlanarYUVLuminanceSource(bytes, 640, 480, 0, 0, 640, 480, false)
                val binaryBitmap = BinaryBitmap(HybridBinarizer(source))
                try {
                    val result = MultiFormatReader().decode(binaryBitmap)
                    onQRCodeRead(result.text)
                } catch (e: NotFoundException) {
                    // QR code not found
                }
            }, null)

            captureRequestBuilder = cameraDevice?.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)?.apply {
                addTarget(surface)
                addTarget(imageReader.surface)
            } ?: return

            cameraDevice?.createCaptureSession(listOf(surface, imageReader.surface), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(session: CameraCaptureSession) {
                    if (cameraDevice == null) return
                    cameraCaptureSession = session
                    captureRequestBuilder.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
                    val captureRequest = captureRequestBuilder.build()
                    cameraCaptureSession?.setRepeatingRequest(captureRequest, null, null)
                }

                override fun onConfigureFailed(session: CameraCaptureSession) {
                    Toast.makeText(context, "Failed to configure camera", Toast.LENGTH_SHORT).show()
                }
            }, null)
        } catch (e: CameraAccessException) {
            Log.e("CameraFallback", "Failed to create camera preview session: ${e.message}")
        }
    }

    private fun closeCamera() {
        try {
            // Acquire the lock to ensure no other open/close calls are in progress
            cameraOpenCloseLock.acquire()

            cameraCaptureSession?.close()
            cameraCaptureSession = null

            cameraDevice?.close()
            cameraDevice = null

        } catch (e: InterruptedException) {
            Log.e("CameraFallback", "Interrupted while trying to close camera.")
        } finally {
            cameraOpenCloseLock.release() // Ensure lock is released
        }
    }

    private fun onQRCodeRead(qrCode: String) {
        val reactContext = context as ReactContext
        val event = Arguments.createMap().apply {
            putString("codeStringValue", qrCode)
        }
        reactContext.getJSModule(RCTEventEmitter::class.java).receiveEvent(
            id, "onReadCode", event // Ensure these match "onReadCode" here and in CKCameraManager
        )
    }



    // Add this if `ActivityCompat` permission handling is needed
    fun handlePermissionsResult(requestCode: Int, grantResults: IntArray) {
        if (requestCode == 100 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            setupTextureView()
        } else {
            Toast.makeText(context, "Camera permission is required", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        closeCamera() // Ensure camera is closed when view is detached
    }

    // Optional lifecycle methods if integrated with activity/fragment lifecycle
    fun onResume() {
        if (textureView.isAvailable) {
            openCamera()
        } else {
            setupTextureView() // Ensure the TextureView is set up again if switching back
        }
    }

    fun onPause() {
        closeCamera()
    }
}
