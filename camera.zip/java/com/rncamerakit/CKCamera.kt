package com.rncamerakit

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.util.AttributeSet
import android.util.DisplayMetrics
import android.util.Log
import android.widget.FrameLayout
import androidx.lifecycle.LifecycleOwner
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.WritableMap
import com.facebook.react.uimanager.ThemedReactContext
import com.facebook.react.uimanager.events.RCTEventEmitter
import com.google.mlkit.vision.barcode.common.Barcode
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import android.util.Size
import android.view.ViewGroup
import android.view.View

internal class MyReactNativeView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    override fun requestLayout() {
        if (isLayoutRequested) return
        super.requestLayout()
        post(measureAndLayout)
    }

    private val measureAndLayout = Runnable {
        measure(
            MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY),
            MeasureSpec.makeMeasureSpec(height, MeasureSpec.EXACTLY)
        )
        layout(left, top, right, bottom)
    }
}

@SuppressLint("ViewConstructor")
class CKCamera(context: ThemedReactContext) : FrameLayout(context) {
    private val currentContext: ThemedReactContext = context

    private var camera: Camera? = null
    private var preview: Preview? = null
    private var imageAnalyzer: ImageAnalysis? = null
    private lateinit var viewFinder: PreviewView
    var isCameraBound = false

    private val cameraExecutor: ExecutorService by lazy {
        Executors.newSingleThreadExecutor()
    }

    private var cameraProvider: ProcessCameraProvider? = null
    private var scanBarcode: Boolean = false

    private val screenMetrics: DisplayMetrics by lazy {
        DisplayMetrics().apply {
            viewFinder.display?.getRealMetrics(this)
        }
    }

    private fun getActivity(): Activity {
        return currentContext.currentActivity!!
    }

    // Helper function to install hierarchy fitter for dynamic layout changes
    private fun installHierarchyFitter(view: ViewGroup) {
        if (view.context is ThemedReactContext) {
            view.setOnHierarchyChangeListener(object : ViewGroup.OnHierarchyChangeListener {
                override fun onChildViewRemoved(parent: View?, child: View?) = Unit
                override fun onChildViewAdded(parent: View?, child: View?) {
                    parent?.measure(
                        View.MeasureSpec.makeMeasureSpec(parent.measuredWidth, View.MeasureSpec.EXACTLY),
                        View.MeasureSpec.makeMeasureSpec(parent.measuredHeight, View.MeasureSpec.EXACTLY)
                    )
                    parent?.layout(parent.left, parent.top, parent.right, parent.bottom)
                }
            })
        }
    }

    init {
        // Initialize PreviewView instead of CameraViewfinder
        viewFinder = PreviewView(context).apply {
            layoutParams = LayoutParams(
                LayoutParams.MATCH_PARENT,
                LayoutParams.MATCH_PARENT
            )
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }

        val myReactNativeView = MyReactNativeView(context)
        installHierarchyFitter(viewFinder) // Add the fitter to viewFinder
        myReactNativeView.addView(viewFinder)
        addView(myReactNativeView)

        // Preload ProcessCameraProvider
        val cameraProviderFuture = ProcessCameraProvider.getInstance(getActivity())
        cameraProviderFuture.addListener({
            cameraProvider = cameraProviderFuture.get()
        }, ContextCompat.getMainExecutor(getActivity()))
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (hasPermissions() && !isCameraBound) {
            viewFinder.post { setupCamera() }
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        cameraProvider?.unbindAll()
        isCameraBound = false
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(getActivity())
        cameraProviderFuture.addListener({
            cameraProvider = cameraProviderFuture.get()
            bindCameraUseCases()
        }, ContextCompat.getMainExecutor(getActivity()))
    }

    private fun bindCameraUseCases() {
        // Prevent redundant binding if already bound or if display is null
        if (isCameraBound || viewFinder.display == null) return

        val screenAspectRatio = aspectRatio(screenMetrics.widthPixels, screenMetrics.heightPixels)
        val rotation = viewFinder.display.rotation
        val cameraProvider = cameraProvider ?: throw IllegalStateException("Camera initialization failed.")
        val cameraSelector: CameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

        val localPreview = Preview.Builder()
            .setTargetAspectRatio(screenAspectRatio)
            .setTargetRotation(rotation)
            .build()
        preview = localPreview

        val useCases = mutableListOf<UseCase>(localPreview)

        // Configure barcode scanner if scanBarcode is enabled
        if (scanBarcode) {
            imageAnalyzer = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setTargetResolution(Size(1280, 720))
                .build()
            val analyzer = QRCodeAnalyzer { barcodes: List<Barcode> ->
                if (barcodes.isNotEmpty()) {
                    onBarcodeRead(barcodes)
                }
            }
            imageAnalyzer!!.setAnalyzer(ContextCompat.getMainExecutor(context), analyzer)
            useCases.add(imageAnalyzer!!)
        }

        // Unbind existing use cases and try to bind new ones
        cameraProvider.unbindAll()

        try {
            camera = cameraProvider.bindToLifecycle(
                getActivity() as LifecycleOwner,
                cameraSelector,
                *useCases.toTypedArray()
            )
            localPreview.setSurfaceProvider(viewFinder.surfaceProvider)

            isCameraBound = true // Set to true once binding is successful
            notifyCameraInitialized()
        } catch (exc: Exception) {
            Log.e(TAG, "Failed to bind use cases: ${exc.message}", exc)
            sendErrorEvent(exc.message ?: "Unknown error")
        }
    }


    private fun notifyCameraInitialized() {
        val event: WritableMap = Arguments.createMap()
        currentContext.getJSModule(RCTEventEmitter::class.java).receiveEvent(id, "onCameraInitialized", event)
    }

    private fun aspectRatio(width: Int, height: Int): Int {
        val previewRatio = max(width, height).toDouble() / min(width, height)
        return if (abs(previewRatio - RATIO_4_3_VALUE) <= abs(previewRatio - RATIO_16_9_VALUE)) {
            AspectRatio.RATIO_4_3
        } else {
            AspectRatio.RATIO_16_9
        }
    }

    private fun onBarcodeRead(barcodes: List<Barcode>) {
        val event: WritableMap = Arguments.createMap()
        val firstBarcode = barcodes.first()
        event.putString("codeStringValue", firstBarcode.rawValue)
        val codeFormat = CodeFormat.fromBarcodeType(firstBarcode.format)
        event.putString("codeFormat", codeFormat.code)
        currentContext.getJSModule(RCTEventEmitter::class.java).receiveEvent(id, "onReadCode", event)
    }

    fun setTorchMode(mode: String?) {
        camera?.cameraControl?.enableTorch(mode == "on")
    }

    fun setScanBarcode(enabled: Boolean) {
        if (enabled != scanBarcode) {
            scanBarcode = enabled
            bindCameraUseCases()
        }
    }

    private fun hasPermissions(): Boolean {
        val requiredPermissions = arrayOf(Manifest.permission.CAMERA)
        if (requiredPermissions.all {
                ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
            }) {
            return true
        }
        ActivityCompat.requestPermissions(
            getActivity(),
            requiredPermissions,
            42
        )
        return false
    }

    private fun sendErrorEvent(message: String) {
        val event: WritableMap = Arguments.createMap()
        event.putString("errorMessage", message)
        currentContext.getJSModule(RCTEventEmitter::class.java).receiveEvent(id, "onError", event)
    }

    companion object {
        private const val TAG = "CameraKit"
        private const val RATIO_4_3_VALUE = 4.0 / 3.0
        private const val RATIO_16_9_VALUE = 16.0 / 9.0
    }
}

object CodeFormat {
    fun fromBarcodeType(format: Int): CodeFormatType {
        return when (format) {
            Barcode.FORMAT_QR_CODE -> CodeFormatType.QR
            Barcode.FORMAT_CODE_128 -> CodeFormatType.CODE128
            else -> CodeFormatType.UNKNOWN
        }
    }
}

enum class CodeFormatType(val code: String) {
    QR("QR"),
    CODE128("Code 128"),
    UNKNOWN("Unknown")
}
